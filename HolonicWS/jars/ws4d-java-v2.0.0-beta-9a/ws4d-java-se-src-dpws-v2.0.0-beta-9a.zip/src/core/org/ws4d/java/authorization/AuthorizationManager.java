/*******************************************************************************
 * Copyright (c) 2009 MATERNA Information & Communications. All rights reserved.
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html. For further
 * project-related information visit http://www.ws4d.org. The most recent
 * version of the JMEDS framework can be obtained from
 * http://sourceforge.net/projects/ws4d-javame.
 ******************************************************************************/
package org.ws4d.java.authorization;

import org.ws4d.java.communication.ConnectionInfo;
import org.ws4d.java.communication.RequestHeader;
import org.ws4d.java.communication.Resource;
import org.ws4d.java.constants.FrameworkConstants;
import org.ws4d.java.eventing.ClientSubscription;
import org.ws4d.java.eventing.EventListener;
import org.ws4d.java.message.InvokeMessage;
import org.ws4d.java.message.eventing.GetStatusMessage;
import org.ws4d.java.message.eventing.RenewMessage;
import org.ws4d.java.message.eventing.SubscribeMessage;
import org.ws4d.java.message.eventing.UnsubscribeMessage;
import org.ws4d.java.message.metadata.GetMessage;
import org.ws4d.java.message.metadata.GetMetadataMessage;
import org.ws4d.java.security.CredentialInfo;
import org.ws4d.java.security.SecurityKey;
import org.ws4d.java.service.LocalDevice;
import org.ws4d.java.service.LocalService;
import org.ws4d.java.service.Operation;
import org.ws4d.java.types.EndpointReference;
import org.ws4d.java.types.URI;
import org.ws4d.java.types.URISet;
import org.ws4d.java.util.Log;

/**
 * The AuthorizationManager manages the authorization.
 */
public abstract class AuthorizationManager {

	private static AuthorizationManager	instance				= null;

	private static boolean				getInstanceFirstCall	= true;

	/**
	 * Returns an implementation of the authorization manager if available,
	 * which allows to check incoming and outgoing messages for rights. If no
	 * implementation is loaded yet attemping to load the
	 * <code>DefaultAuthorizationManager</code> .
	 * 
	 * @return an implementation of the authorization manager.
	 */
	public static synchronized AuthorizationManager getInstance() {
		if (getInstanceFirstCall) {
			getInstanceFirstCall = false;
			try {
				// default =
				// "org.ws4d.java.authorization.DefaultAuthorizationManager"
				Class clazz = Class.forName(FrameworkConstants.DEFAULT_AUTHORIZATION_MANAGER_PATH);
				instance = ((AuthorizationManager) clazz.newInstance());
			} catch (Exception e) {
				if (Log.isWarn()) {
					Log.warn("Unable to create DefaultAuthorizationManager: " + e.getMessage());
				}
			}
		}
		return instance;
	}

	public void addRequestURI2ServiceId(URI requestURI, URI serviceId, EndpointReference deviceEpr) {}

	public void addRequestURI2deviceEPR(URI requestURI, EndpointReference deviceEpr) {}

	public void removeRequestURI2ServiceId(URI requestURI) {}

	protected void defaultCheckRemote(ConnectionInfo connectionInfo) {
		throw new AuthorizationException();
	}

	protected void defaultCheckLocal(CredentialInfo credentialInfo) {
		throw new AuthorizationException();
	}

	// get device
	public void checkDevice(LocalDevice localDevice, GetMessage get, ConnectionInfo connectionInfo) throws AuthorizationException {
		defaultCheckRemote(connectionInfo);
	}

	public void checkDevice(LocalDevice localDevice, SecurityKey securityKey) throws AuthorizationException {
		defaultCheckLocal(securityKey.getLocalCredentialInfo());
	}

	// get service
	public void checkService(LocalService localService, GetMetadataMessage getMetadata, ConnectionInfo connectionInfo) throws AuthorizationException {
		defaultCheckRemote(connectionInfo);
	}

	public void checkService(LocalService localService, SecurityKey securityKey) throws AuthorizationException {
		defaultCheckLocal(securityKey.getLocalCredentialInfo());
	}

	// get resource
	public void checkResource(URI request, RequestHeader header, Resource resource, ConnectionInfo connectionInfo) throws AuthorizationException {
		defaultCheckRemote(connectionInfo);
	}

	/*
	 * Invoke Messages
	 */

	// invoke operation
	public void checkInvoke(LocalService localService, Operation op, InvokeMessage invoke, ConnectionInfo connectionInfo) throws AuthorizationException {
		defaultCheckRemote(connectionInfo);
	}

	public void checkInvoke(LocalService localService, Operation op, CredentialInfo credentialInfo) throws AuthorizationException {
		defaultCheckLocal(credentialInfo);
	}

	// invoke event
	public void checkEvent(EventListener eventListener, ClientSubscription clientSubscripton, InvokeMessage invoke, ConnectionInfo connectionInfo) throws AuthorizationException {
		defaultCheckRemote(connectionInfo);
	}

	public void checkEvent(EventListener eventListener, ClientSubscription clientSubscripton, URI actionUri, CredentialInfo credentialInfo) throws AuthorizationException {
		defaultCheckLocal(credentialInfo);
	}

	/*
	 * Eventing Messages
	 */

	// subscribe
	public void checkSubscribe(LocalService localService, SubscribeMessage subscribe, ConnectionInfo connectionInfo) throws AuthorizationException {
		defaultCheckRemote(connectionInfo);
	}

	public void checkSubscribe(LocalService localService, String clientSubscriptionId, URISet eventActionURIs, long duration, CredentialInfo credentialInfo) throws AuthorizationException {
		defaultCheckLocal(credentialInfo);
	}

	// unsubscribe
	public void checkUnsubscribe(LocalService localService, UnsubscribeMessage unsubscribe, ConnectionInfo connectionInfo) throws AuthorizationException {
		defaultCheckRemote(connectionInfo);
	}

	public void checkUnsubscribe(LocalService localService, ClientSubscription subscription, CredentialInfo credentialInfo) throws AuthorizationException {
		defaultCheckLocal(credentialInfo);
	}

	// getStatus
	public void checkGetStatus(LocalService localService, GetStatusMessage getStatus, ConnectionInfo connectionInfo) throws AuthorizationException {
		defaultCheckRemote(connectionInfo);
	}

	public void checkGetStatus(LocalService localService, ClientSubscription subscription, CredentialInfo credentialInfo) throws AuthorizationException {
		defaultCheckLocal(credentialInfo);
	}

	// renew
	public void checkRenew(LocalService localService, RenewMessage renew, ConnectionInfo connectionInfo) throws AuthorizationException {
		defaultCheckRemote(connectionInfo);
	}

	public void checkRenew(LocalService localService, ClientSubscription subscription, long duration, CredentialInfo credentialInfo) throws AuthorizationException {
		defaultCheckLocal(credentialInfo);
	}
}
