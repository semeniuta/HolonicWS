package org.ws4d.java.eventing;

import org.ws4d.java.structures.Set;

public interface OutgoingDiscoveryInfosProvider {

	public Set getOutgoingDiscoveryInfos();
}
