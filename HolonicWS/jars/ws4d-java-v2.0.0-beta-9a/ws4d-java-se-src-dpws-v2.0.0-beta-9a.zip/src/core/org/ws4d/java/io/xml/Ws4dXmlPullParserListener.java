package org.ws4d.java.io.xml;

public interface Ws4dXmlPullParserListener {

	public void notify(int startpos, int endpos);
}
