package org.ws4d.java.security;

public interface KeyManagers {

}
