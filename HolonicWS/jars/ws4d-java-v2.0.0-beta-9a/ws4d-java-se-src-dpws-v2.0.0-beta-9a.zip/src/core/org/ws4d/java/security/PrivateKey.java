package org.ws4d.java.security;

public interface PrivateKey {

	public Object getPrivateKeyAsObject();

}
