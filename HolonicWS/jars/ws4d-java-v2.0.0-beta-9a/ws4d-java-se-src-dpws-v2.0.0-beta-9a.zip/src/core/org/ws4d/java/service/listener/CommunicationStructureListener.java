package org.ws4d.java.service.listener;

public interface CommunicationStructureListener {

}
