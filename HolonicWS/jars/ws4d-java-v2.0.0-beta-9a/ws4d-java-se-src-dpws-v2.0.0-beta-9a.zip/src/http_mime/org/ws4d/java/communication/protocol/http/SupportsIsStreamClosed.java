package org.ws4d.java.communication.protocol.http;

public interface SupportsIsStreamClosed {

	public boolean isStreamClosed();
}
