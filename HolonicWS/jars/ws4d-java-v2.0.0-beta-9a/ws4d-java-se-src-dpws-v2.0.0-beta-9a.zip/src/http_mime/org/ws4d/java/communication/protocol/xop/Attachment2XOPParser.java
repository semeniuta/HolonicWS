package org.ws4d.java.communication.protocol.xop;

public class Attachment2XOPParser {

}
