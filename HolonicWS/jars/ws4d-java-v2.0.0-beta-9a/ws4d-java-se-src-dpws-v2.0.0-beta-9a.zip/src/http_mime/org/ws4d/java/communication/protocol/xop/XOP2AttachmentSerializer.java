package org.ws4d.java.communication.protocol.xop;

public class XOP2AttachmentSerializer {

}
